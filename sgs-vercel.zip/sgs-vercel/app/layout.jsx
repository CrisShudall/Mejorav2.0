export const metadata = {
  title: "Folios & Asistencia — Siniestros y Auto Sustituto",
  description: "Sistema de gestión de folios de siniestros y reportes de auto sustituto",
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  );
}
