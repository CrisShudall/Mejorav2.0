import { put, head } from "@vercel/blob";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const VALID_KEYS = [
  "sgs_users_v1",
  "sgs_providers_v1",
  "sgs_siniestros_v1",
  "sgs_autosustituto_v1",
];

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const key = searchParams.get("key");
  if (!VALID_KEYS.includes(key)) {
    return Response.json({ error: "invalid key" }, { status: 400 });
  }
  try {
    const info = await head(`data/${key}.json`);
    const res = await fetch(info.url, { cache: "no-store" });
    const text = await res.text();
    return new Response(text, {
      headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    // No existe todavía: el cliente usará su semilla por defecto.
    return Response.json(null);
  }
}

export async function POST(request) {
  const { searchParams } = new URL(request.url);
  const key = searchParams.get("key");
  if (!VALID_KEYS.includes(key)) {
    return Response.json({ error: "invalid key" }, { status: 400 });
  }
  const body = await request.text();
  try {
    await put(`data/${key}.json`, body, {
      access: "public",
      addRandomSuffix: false,
      allowOverwrite: true,
      contentType: "application/json",
    });
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
